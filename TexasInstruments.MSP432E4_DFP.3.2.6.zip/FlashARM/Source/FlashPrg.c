/* -----------------------------------------------------------------------------
 * Copyright (c) 2014 ARM Ltd.
 *
 * This software is provided 'as-is', without any express or implied warranty. 
 * In no event will the authors be held liable for any damages arising from 
 * the use of this software. Permission is granted to anyone to use this 
 * software for any purpose, including commercial applications, and to alter 
 * it and redistribute it freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not 
 *    claim that you wrote the original software. If you use this software in
 *    a product, an acknowledgment in the product documentation would be 
 *    appreciated but is not required. 
 * 
 * 2. Altered source versions must be plainly marked as such, and must not be 
 *    misrepresented as being the original software. 
 * 
 * 3. This notice may not be removed or altered from any source distribution.
 */
 
/***********************************************************************/
/*                                                                     */
/*  FlashPrg.c:  Flash Programming Functions adapted                   */
/*               by Texas Instruments for                              */
/*               MSP432 Flash Loader for Keil �Vision IDE              */
/*                                                                     */
/*  Version:     3.2.0                                                 */
/*  Date:        2017-09-13                                            */
/***********************************************************************/


// Defines
#define FLASH_MAX_REPEATS       5

#include <stdint.h>
#include <stdbool.h>

#include "..\FlashOS.H"        // FlashOS Structures

#include "msp.h"

// Function prototypes
void unlockAllFlashSectors(bool eraseBSL);
void lockAllFlashSectors(void);
	
/*
 *  Initialize Flash Programming Functions
 *    Parameter:      adr:  Device Base Address
 *                    clk:  Clock Frequency (Hz)
 *                    fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */
int Init (unsigned long adr, unsigned long clk, unsigned long fnc)
{
	// disable interrupts
	__disable_irq();

	// Halt watchdog
	SYSCTL->RCGCWD &= ~(SYSCTL_RCGCWD_R1 + SYSCTL_RCGCWD_R0);

	return (0);                                  // Finished without Errors
}


/*
 *  De-Initialize Flash Programming Functions
 *    Parameter:      fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */

int UnInit (unsigned long fnc)
{
	return (0);                                  // Finished without Errors
}


/*
 *  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 */

int EraseChip (void)
{
	bool success = false;

	// Clear the flash access and error interrupts.
	FLASH_CTRL->FCMISC = (FLASH_FCMISC_AMISC | FLASH_FCMISC_VOLTMISC |
												FLASH_FCMISC_ERMISC | FLASH_FCMISC_PMISC);

	// Trigger mass erase
	FLASH_CTRL->FMC = FLASH_FMC_WRKEY | FLASH_FMC_MERASE;
	
	while(FLASH_CTRL->FMC & FLASH_FMC_MERASE);

	// Return an error if an access violation occurred.
	success = !(FLASH_CTRL->FCRIS & (FLASH_FCRIS_ARIS | FLASH_FCRIS_VOLTRIS |
																	FLASH_FCRIS_ERRIS));
  if (!success)
  {
    return (1);
  }
  else
  {
    return (0);
  }  
}


/*
 *  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  1 - Failed
 */

int EraseSector (unsigned long adr)
{
	bool success = false;

	// Clear the flash access and error interrupts.
	FLASH_CTRL->FCMISC = (FLASH_FCMISC_AMISC | FLASH_FCMISC_VOLTMISC |
												FLASH_FCMISC_ERMISC | FLASH_FCMISC_PMISC);

	// Set 16kB aligned flash page address to be erased (16kB block)
	FLASH_CTRL->FMA = adr;
	
	// Trigger sector erase (erase flash page)
	FLASH_CTRL->FMC = FLASH_FMC_WRKEY | FLASH_FMC_ERASE;
	
	while(FLASH_CTRL->FMC & FLASH_FMC_ERASE);

	// Return an error if an access violation occurred.
	success = !(FLASH_CTRL->FCRIS & (FLASH_FCRIS_ARIS | FLASH_FCRIS_VOLTRIS |
																	FLASH_FCRIS_ERRIS));
	if (!success)
	{
		return (1);
	}
	else
	{
		return (0);
	}  
}


/*
 *  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */

int ProgramPage (unsigned long adr, unsigned long sz, unsigned char *buf)
{
	bool success = true;
	int i = 0;
	uint32_t address = (uint32_t) adr;
  int32_t wordsToProgram = (int32_t)sz;	
  unsigned long *pulData = (unsigned long *) buf;
	
	// Address must be WORD aligned
	if (adr & 3)
	{
		return 1;
	}

  //
  // Clear the flash access interrupt and error interrupts.
  //
  FLASH_CTRL->FCMISC = (FLASH_FCMISC_AMISC | FLASH_FCMISC_VOLTMISC | 
      FLASH_FCMISC_INVDMISC | FLASH_FCMISC_PROGMISC | FLASH_FCMISC_PMISC);
  //
  // Loop over the words to be programmed.
  //
  while((wordsToProgram > 0) && success)
  {
    //
    // Program the next word.
    //
    for(i = 0; i < 32; i++)
    {
      if ( pulData >= (unsigned long *)(buf + sz))
      {
        FLASH_CTRL->FWBN[i] = 0xFF;
      }
      else
      {
        FLASH_CTRL->FWBN[i] = *pulData++;
      }
    }    
    FLASH_CTRL->FMA = address;
    FLASH_CTRL->FMC2 = FLASH_FMC_WRKEY | FLASH_FMC2_WRBUF;

    //
    // Wait until the word has been programmed.
    //
    while(FLASH_CTRL->FMC2 & FLASH_FMC2_WRBUF);

    //
    // Return an error if an access violation occurred.
    //
    success = (success && !(FLASH_CTRL->FCRIS & (FLASH_FCRIS_ARIS |
																					FLASH_FCRIS_PROGRIS | FLASH_FCRIS_INVDRIS)));
		
    FLASH_CTRL->FCMISC = FLASH_FCMISC_PMISC;
    //
    // Increment to the next word.
    //
    address += 128;
    wordsToProgram -= 128;
  }

  if (!success)
  {
    return (1);
  }
  else
  {
    return (0);
  }  
}

